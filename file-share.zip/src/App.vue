<script setup lang="ts">

</script>
<template>
  <RouterView />
</template>

<style scoped lang="scss">
.homepage {
  color: red;
}
</style>
