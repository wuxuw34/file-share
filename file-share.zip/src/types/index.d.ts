declare interface Window {
    $baseURL:string
}

 type MessageResultType = {
    data?:any;
    state:number;
    msg:string;
}