

class ProgramConfig{
    
    readonly db_config = {
        host:'localhost',
        user:'file',
        password:'file',
        database:'file'
    }

}

const config = new ProgramConfig()

export default config