import { nanoid } from 'nanoid'

function random(){
    return nanoid(5)
}

export default random