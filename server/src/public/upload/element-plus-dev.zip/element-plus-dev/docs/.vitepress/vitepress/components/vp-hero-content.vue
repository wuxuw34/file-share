<template>
  <div class="hero-content">
    <Content />
  </div>
  <el-divider style="margin-bottom: 0" />
  <div class="text-center py-6 text-xs">
    <p class="mb-1">
      Released under the
      <a
        href="https://opensource.org/licenses/MIT"
        target="_blank"
        rel="noopener noreferer"
        >MIT License</a
      >.
    </p>
    <p class="mt-1">
      Made with ❤️ by
      <a
        href="https://github.com/element-plus"
        target="_blank"
        rel="noopener noreferer"
        >Element Plus</a
      >
    </p>
  </div>
</template>
