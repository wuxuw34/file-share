export const define = <T>(value: T): T => value
