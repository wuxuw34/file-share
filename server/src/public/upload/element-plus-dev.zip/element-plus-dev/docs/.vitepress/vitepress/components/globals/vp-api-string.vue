<script setup lang="ts">
import Primitive from './vp-api-primitive.vue'
</script>

<template>
  <Primitive type="string" />
</template>
