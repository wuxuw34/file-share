<template>
  <!-- Generator: Adobe Illustrator 26.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
  <svg
    id="图层_1"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 120 120"
    style="enable-background: new 0 0 120 120"
    xml:space="preserve"
  >
    <path
      class="st0"
      d="M7,14h106c1.1,0,2,0.9,2,2v68c0,1.1-0.9,2-2,2H7c-1.1,0-2-0.9-2-2V16C5,14.9,5.9,14,7,14z"
    />
    <path
      class="st1"
      d="M60,46c0-3.3,2.7-6,6-6l0,0c3.3,0,6,2.7,6,6l0,0c0,3.3-2.7,6-6,6l0,0C62.7,52,60,49.3,60,46L60,46z"
    />
    <path
      class="st2"
      d="M48,58c0-3.3,2.7-6,6-6h6v6c0,3.3-2.7,6-6,6l0,0C50.7,64,48,61.3,48,58L48,58z"
    />
    <path class="st3" d="M60,28v12h6c3.3,0,6-2.7,6-6l0,0c0-3.3-2.7-6-6-6H60z" />
    <path
      class="st4"
      d="M48,34c0,3.3,2.7,6,6,6h6V28h-6C50.7,28,48,30.7,48,34L48,34z"
    />
    <path
      class="st5"
      d="M48,46c0,3.3,2.7,6,6,6h6V40h-6C50.7,40,48,42.7,48,46L48,46z"
    />
    <path class="st6" d="M5,74h110v10c0,1.1-0.9,2-2,2H7c-1.1,0-2-0.9-2-2V74z" />
    <circle class="st7" cx="60" cy="80" r="2" />
    <path
      class="st8"
      d="M46.8,86L38,103.1c-0.7,1.3,0.3,2.9,1.8,2.9H60V86H46.8z M73.2,86l8.7,17.1c0.7,1.3-0.3,2.9-1.8,2.9H60V86H73.2
	z"
    />
  </svg>
</template>

<style scoped lang="scss">
.st0 {
  fill: #f2f8fe;
}
.st1 {
  fill: #1abcfe;
}
.st2 {
  fill: #0acf83;
}
.st3 {
  fill: #ff7262;
}
.st4 {
  fill: #f24e1e;
}
.st5 {
  fill: #a259ff;
}
.st6 {
  fill: #20a0ff;
}
.st7 {
  fill: #ffffff;
}
.st8 {
  fill-rule: evenodd;
  clip-rule: evenodd;
  fill: #deecf9;
}

.dark {
  .st0 {
    fill: #272829;
  }
  .st8 {
    fill-rule: evenodd;
    clip-rule: evenodd;
    fill: #373f48;
  }
}
</style>
