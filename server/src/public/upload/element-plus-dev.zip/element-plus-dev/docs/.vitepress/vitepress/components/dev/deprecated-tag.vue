<template>
  <el-tag size="small" type="warning" effect="plain" hit round class="ml-2"
    >deprecated</el-tag
  >
</template>
