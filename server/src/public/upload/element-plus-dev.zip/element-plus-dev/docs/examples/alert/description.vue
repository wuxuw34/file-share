<template>
  <el-alert
    title="with description"
    type="success"
    description="This is a description."
  />
</template>
