<template>
  <el-empty :image-size="200" />
</template>
