<template>
  <div>
    <span>What language is thine, O sea?</span>
    <el-divider border-style="dashed" />
    <span>The language of eternal question.</span>
  </div>
  <el-divider border-style="dotted" />
  <span>What language is thy answer, O sky?</span>
  <el-divider border-style="double" />
  <span>The language of eternal silence.</span>
</template>
